package Sauc_Utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Sauc_Screenshot {


	static int counter =0;
	 WebDriver dr;
	
	public Sauc_Screenshot(WebDriver dr)
	{
		this.dr =dr;
	}
	 
	public void ScreenShott()
	{
		String	path="C:\\Users\\BLTuser.BLT0215\\Documents\\ScreenShot\\";
		String FileName=counter+".png";

		File f1 = ((TakesScreenshot) dr).getScreenshotAs(OutputType.FILE);
		File f2 = new File(path+FileName);
		try {
			FileUtils.copyFile(f1, f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
		}
				
		counter++;
	}
}


