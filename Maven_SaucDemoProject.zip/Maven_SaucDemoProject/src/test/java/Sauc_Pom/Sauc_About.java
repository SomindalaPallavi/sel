package Sauc_Pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Sauc_Utilities.Sauc_Wait;

public class Sauc_About {

	WebDriver dr;
	Sauc_Wait sw;
	
	By ab=By.xpath("//a[text()='About']");
	
	By fi=By.xpath("//a[@class='button is-rounded is-primary'][contains(text(),'Learn more')]");
	
	public Sauc_About(WebDriver dr)
	{
		this.dr=dr;
		sw=new Sauc_Wait(dr);
	}
	
	public void abo()
	{
		dr.findElement(ab).click();
	}
	
	public void field()
	{
		dr.findElement(fi).click();
	}
	
	public void Sel_Field()
	{
		this.abo();
		this.field();
	}	
}
