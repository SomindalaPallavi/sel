package alas_library;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class alas_utilities{

	WebDriver dr;
	public alas_utilities(WebDriver dr) {
		
		this.dr=dr;
	}
	public WebDriver launch_browser1(String url) {
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get(url);
		dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return dr;
		
		
	}
	public WebDriver launch_browser2(String url) {
		System.setProperty("webdriver.gecko.driver","geckodriver.exe");
		dr=new FirefoxDriver();
		dr.get(url);
		return dr;
		
	
	

}
}

//public WebElement waitForElement(By locator,int timeout) {
//
//try {
//	
//	WebDriverWait wait=new WebDriverWait(dr,timeout);
//	WebElement element=wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
//	System.out.println("Element Located");
//	return element;
//}catch(Exception e) {
//	System.out.println("Element not located"+e);
//}
//return null;
//}
//
//public WebElement elementToBeClickable(By locator,int timeout) {
//
//try {
//	
//	WebDriverWait wait=new WebDriverWait(dr,timeout);
//	WebElement element =wait.until(ExpectedConditions.elementToBeClickable(locator));
//	System.out.println("Element Located");
//	return element;
//}catch(Exception e) {
//	System.out.println("Element not located"+e);
//}
//return null;
//}
//
//
//
//public void getScreenshot() {
//
//String path="C:\\Users\\BLTuser.BLT223\\Desktop\\New folder\\i4";
//String filename=counter+".png";
//
//File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
//File f2=new File(path+filename);
//try {
//	FileUtils.copyFile(f1,f2);
//} catch (IOException e) {
//	// TODO Auto-generated catch block
//	e.printStackTrace();
//}
//counter++;
//}
