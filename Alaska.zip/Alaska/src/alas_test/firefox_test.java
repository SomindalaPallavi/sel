package alas_test;



import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import alas_library.alas_utilities;
import alas_page.first_page;
import alas_page.five_page;
import alas_page.four_page;
import alas_page.second_page;
import alas_page.third_page;

public class firefox_test {
	
	WebDriver dr;
	alas_utilities ru;
	first_page fp;
	second_page sp;
	third_page tp;
	four_page fop;
	five_page fip;
	
	String url="https://www.royalcaribbean.com/alaska-cruises";
	
	@BeforeClass
	public void bc()
	{
		ru=new alas_utilities(dr);
		dr=ru.launch_browser2(url);
	}
	
  @Test
  public void f() {
	  fp=new first_page(dr);
	  sp=new second_page(dr);
	  tp=new third_page(dr);
	  fop=new four_page(dr);
	  fip=new five_page(dr);
	 
	  boolean a=fp.set_whale();

	  fp.first();
	  sp.second();
	  tp.third();
	  fop.four();
	  fip.five();
	  boolean b=fip.roy();
	  
	  SoftAssert sa=new SoftAssert();
	  sa.assertTrue(a,"Doesnot meet my requirements");
	  sa.assertTrue(b);
	  sa.assertAll();
	  
	  
  }
}
