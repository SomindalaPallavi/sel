package alas_page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import alas_library.alas_utilities;

public class first_page {

	WebDriver dr;
	alas_utilities ru;
	
	By whale=By.partialLinkText("whale watching");
	
	By by_b= By.xpath("//button[@id='rciHeaderOpenSidenav']/div");//button
	
	By by_p= By.xpath("//a[@id='rciHeaderSideNavMenu-1']");//Plan a cruise
	
	By by_f= By.xpath("//a[@id='rciHeaderSideNavSubmenu-1-1']");//Find a cruise
	
	public first_page(WebDriver dr) 
	{
		this.dr=dr;
		ru=new alas_utilities(dr);
	}
	
	public boolean set_whale() 
	{
		boolean a =dr.findElement(whale).isEnabled();
		
		return a;
	}
	
	public void bu()
	{
		dr.findElement(by_b).click();
	}
	
	public void pc()
	{
		dr.findElement(by_p).click();
	}
	
	public void fc()
	{
		dr.findElement(by_f).click();
	}
	
	public void first()
	{
		this.bu();
		this.pc();
		this.fc();
	}
}
