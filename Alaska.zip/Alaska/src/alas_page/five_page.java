package alas_page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import alas_library.alas_utilities;

public class five_page {

	WebDriver dr;
	alas_utilities ru;
	
	By by_de= By.xpath("//select[@id='deckDropdown']");//Deck dropdown
	
	By by_de1= By.xpath("//select[@id='deckDropdown']/option[7]");//Deck Eight
	
	By by_ro= By.xpath("//section[@class='deck-plan__stateroom']//section/div[2]//child::section[5]/h4");//Deck Eight
	
	public five_page(WebDriver dr) {
		
		this.dr=dr;
		ru=new alas_utilities(dr);
	}
	
	public void dec()
	{
//		dr.findElement(by_de).click();
		
		dr.findElement(by_de1).click();
	}
	
	public boolean roy()
	{
		boolean b=dr.findElement(by_ro).isDisplayed();

		return b;
	}
	
	public void five()
	{
		this.dec();
		this.roy();
	}
	
}
