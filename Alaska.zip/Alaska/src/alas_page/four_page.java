package alas_page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import alas_library.alas_utilities;

public class four_page {


	WebDriver dr;
	alas_utilities ru;
	
	By by_d= By.xpath("//div[@class='filterSetDestination__container']/div[3]");//Deck plans

	public four_page(WebDriver dr) {
		
		this.dr=dr;
		ru=new alas_utilities(dr);
	}

	public void four()
	{
		dr.findElement(by_d).click();
	}
}
